package neonbrickbreaker;

import java.awt.*;

public class Brick {

    public int x;
    public int y;

    public int width;
    public int height;

    public int maxHits;
    public int hitsLeft;

    public boolean destroyed;


    public Brick(
            int x,
            int y,
            int width,
            int height,
            int hits) {

        this.x = x;
        this.y = y;

        this.width = width;
        this.height = height;

        maxHits = hits;
        hitsLeft = hits;
    }


    public void hit() {

        hitsLeft--;

        if (hitsLeft <= 0) {

            destroyed = true;
        }
    }


    public Rectangle getBounds() {

        return new Rectangle(
                x + 3,
                y + 3,
                width - 6,
                height - 6
        );
    }


    public Color getColor() {

        if (hitsLeft == 3) {

            return new Color(
                    190,
                    70,
                    255
            );
        }

        if (hitsLeft == 2) {

            return new Color(
                    255,
                    160,
                    40
            );
        }

        return new Color(
                40,
                210,
                255
        );
    }


    public void draw(
            Graphics2D g) {

        g.setColor(
                getColor()
        );

        g.fillRoundRect(
                x + 3,
                y + 3,
                width - 6,
                height - 6,
                10,
                10
        );


        g.setColor(
                new Color(
                        255,
                        255,
                        255,
                        100
                )
        );

        g.drawRoundRect(
                x + 3,
                y + 3,
                width - 6,
                height - 6,
                10,
                10
        );


        if (maxHits > 1) {

            g.setColor(
                    Color.WHITE
            );

            g.setFont(
                    new Font(
                            "Arial",
                            Font.BOLD,
                            12
                    )
            );

            String hp =
                    "" + hitsLeft;

            int tx =
                    x
                    + width / 2
                    - g.getFontMetrics()
                    .stringWidth(hp)
                    / 2;

            g.drawString(
                    hp,
                    tx,
                    y + height - 8
            );
        }
    }
}