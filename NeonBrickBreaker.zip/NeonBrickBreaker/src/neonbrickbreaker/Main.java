package neonbrickbreaker;

import javax.swing.JFrame;

public class Main {

    public static JFrame frame;
    public static String currentPlayer = "PLAYER";

    public static final int WIDTH = 1280;
    public static final int HEIGHT = 720;

    public static void main(String[] args) {

        frame = new JFrame("NEON BREAK");

        frame.setDefaultCloseOperation(
                JFrame.EXIT_ON_CLOSE
        );

        frame.setSize(WIDTH, HEIGHT);

        frame.setResizable(false);

        frame.setLocationRelativeTo(null);

        frame.setContentPane(
                new LoadingScreen(frame)
        );

        frame.setVisible(true);
    }
}
