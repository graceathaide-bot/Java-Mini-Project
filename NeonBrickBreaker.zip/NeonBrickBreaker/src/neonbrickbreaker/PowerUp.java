package neonbrickbreaker;

import java.awt.*;

public class PowerUp {

    public double x;
    public double y;

    public int size = 28;

    public String type;

    private double speed = 2.5;


    public PowerUp(
            double x,
            double y,
            String type) {

        this.x = x;
        this.y = y;

        this.type = type;
    }


    public void update() {

        y += speed;
    }


    public void draw(
            Graphics2D g) {

        Color color;


        if (type.equals("PADDLE")) {

            color = Color.CYAN;

        } else if (type.equals("SLOW")) {

            color = Color.YELLOW;

        } else if (type.equals("LIFE")) {

            color = Color.GREEN;

        } else {

            color = Color.MAGENTA;
        }


        g.setColor(color);

        g.fillRoundRect(
                (int)x,
                (int)y,
                size,
                size,
                8,
                8
        );


        g.setColor(Color.WHITE);

        g.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        13
                )
        );

        g.drawString(
                type.substring(0, 1),
                (int)x + 9,
                (int)y + 19
        );
    }
}