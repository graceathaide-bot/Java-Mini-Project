package neonbrickbreaker;

import java.awt.*;

public class Obstacle {

    private int x;
    private int y;

    private int width;
    private int height;


    public Obstacle(
            int x,
            int y,
            int width,
            int height) {

        this.x = x;
        this.y = y;

        this.width = width;
        this.height = height;
    }


    public Rectangle getBounds() {

        return new Rectangle(
                x,
                y,
                width,
                height
        );
    }


    public void draw(
            Graphics2D g) {

        g.setColor(
                new Color(
                        140,
                        60,
                        230
                )
        );

        g.fillRoundRect(
                x,
                y,
                width,
                height,
                12,
                12
        );


        g.setColor(
                new Color(
                        255,
                        255,
                        255,
                        120
                )
        );

        g.drawRoundRect(
                x,
                y,
                width,
                height,
                12,
                12
        );
    }
}