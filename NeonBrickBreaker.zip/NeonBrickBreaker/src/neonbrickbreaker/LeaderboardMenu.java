package neonbrickbreaker;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;

public class LeaderboardMenu extends JPanel {

    private JFrame frame;

    private JTextArea display;


    public LeaderboardMenu(
            JFrame frame) {

        this.frame = frame;

        setLayout(null);

        setBackground(
                new Color(
                        5, 5, 18
                )
        );


        JLabel title =
                new JLabel(
                        "ARCADE LEADERBOARD",
                        SwingConstants.CENTER
                );

        title.setBounds(
                300,
                35,
                680,
                60
        );

        title.setForeground(
                Color.CYAN
        );

        title.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        40
                )
        );

        add(title);


        display =
                new JTextArea();

        display.setBounds(
                300,
                130,
                680,
                390
        );

        display.setEditable(false);

        display.setBackground(
                new Color(
                        10, 10, 30
                )
        );

        display.setForeground(
                Color.WHITE
        );

        display.setFont(
                new Font(
                        "Monospaced",
                        Font.PLAIN,
                        17
                )
        );

        add(display);


        JButton back =
                new JButton(
                        "BACK TO MENU"
                );

        back.setBounds(
                490,
                560,
                300,
                48
        );

        style(back);

        add(back);


        back.addActionListener(
                e -> {

                    frame.setContentPane(
                            new MainMenu(frame)
                    );

                    frame.revalidate();
                    frame.repaint();
                }
        );


        updateDisplay();
    }


    private void updateDisplay() {

        StringBuilder text =
                new StringBuilder();


        text.append(
                "              NEON ARCADE\n\n"
        );


        for (int level = 1;
             level <= 5;
             level++) {

            text.append(
                    " LEVEL "
                    + level
                    + "  •  "
                    + getDifficulty(level)
                    + "\n"
            );


            text.append(
                    " ───────────────────────────────\n"
            );


            ArrayList<
                    Leaderboard.Record>
                    list =
                    Leaderboard
                    .getScores(level);


            if (list.isEmpty()) {

                text.append(
                        "     NO RECORDS YET\n\n"
                );

            } else {

                for (int i = 0;
                     i < list.size();
                     i++) {

                    Leaderboard.Record r =
                            list.get(i);


                    text.append(
                            String.format(
                                    "  %d. %-12s %s\n",
                                    i + 1,
                                    r.name,
                                    Leaderboard
                                    .formatTime(
                                            r.time
                                    )
                            )
                    );
                }


                text.append("\n");
            }
        }


        display.setText(
                text.toString()
        );
    }


    private String getDifficulty(
            int level) {

        switch (level) {

            case 1:
                return "EASY";

            case 2:
                return "NORMAL";

            case 3:
                return "HARD";

            case 4:
                return "EXTREME";

            default:
                return "NIGHTMARE";
        }
    }


    private void style(
            JButton button) {

        button.setForeground(
                Color.WHITE
        );

        button.setBackground(
                new Color(
                        15, 15, 40
                )
        );

        button.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        16
                )
        );

        button.setFocusPainted(false);

        button.setBorder(
                BorderFactory.createLineBorder(
                        Color.CYAN
                )
        );
    }
}