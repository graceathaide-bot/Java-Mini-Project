package neonbrickbreaker;

import java.awt.*;
import java.util.ArrayList;

public class Ball {

    public double x;
    public double y;

    public double dx;
    public double dy;

    public int size = 16;

    private ArrayList<double[]> trail =
            new ArrayList<>();


    public Ball(
            double x,
            double y,
            double dx,
            double dy) {

        this.x = x;
        this.y = y;

        this.dx = dx;
        this.dy = dy;
    }


    public void update(
            boolean animations) {

        if (animations) {

            trail.add(
                    new double[]{
                        x,
                        y
                    }
            );

            if (trail.size() > 10) {

                trail.remove(0);
            }
        }

        x += dx;
        y += dy;
    }


    public void draw(
            Graphics2D g,
            boolean animations) {

        if (animations) {

            for (int i = 0;
                 i < trail.size();
                 i++) {

                double[] p =
                        trail.get(i);

                int alpha =
                        (i + 1) * 15;

                g.setColor(
                        new Color(
                                0,
                                220,
                                255,
                                alpha
                        )
                );

                g.fillOval(
                        (int)p[0],
                        (int)p[1],
                        size,
                        size
                );
            }
        }


        g.setColor(Color.WHITE);

        g.fillOval(
                (int)x,
                (int)y,
                size,
                size
        );


        g.setColor(Color.CYAN);

        g.drawOval(
                (int)x - 4,
                (int)y - 4,
                size + 8,
                size + 8
        );
    }
}
