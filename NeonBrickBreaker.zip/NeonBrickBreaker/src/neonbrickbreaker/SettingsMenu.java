package neonbrickbreaker;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class SettingsMenu extends JPanel {

    private JFrame frame;

    private JLabel leftLabel;
    private JLabel rightLabel;
    private JLabel pauseLabel;


    public SettingsMenu(
            JFrame frame) {

        this.frame = frame;

        Settings.load();

        setLayout(null);

        setBackground(
                new Color(
                        5, 5, 18
                )
        );


        JLabel title =
                new JLabel(
                        "SETTINGS",
                        SwingConstants.CENTER
                );

        title.setBounds(
                340,
                60,
                600,
                55
        );

        title.setForeground(
                Color.CYAN
        );

        title.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        40
                )
        );

        add(title);


        leftLabel =
                createLabel(
                        "Move Left",
                        170
                );

        rightLabel =
                createLabel(
                        "Move Right",
                        240
                );

        pauseLabel =
                createLabel(
                        "Pause",
                        310
                );


        JButton left =
                createButton(
                        "CHANGE",
                        170
                );

        JButton right =
                createButton(
                        "CHANGE",
                        240
                );

        JButton pause =
                createButton(
                        "CHANGE",
                        310
                );


        add(left);
        add(right);
        add(pause);


        left.addActionListener(
                e -> changeKey(1)
        );

        right.addActionListener(
                e -> changeKey(2)
        );

        pause.addActionListener(
                e -> changeKey(3)
        );


        JCheckBox animations =
                new JCheckBox(
                        "ENABLE ANIMATIONS"
                );

        animations.setBounds(
                490,
                390,
                300,
                35
        );

        animations.setSelected(
                Settings.animations
        );

        animations.setForeground(
                Color.WHITE
        );

        animations.setBackground(
                new Color(
                        5, 5, 18
                )
        );

        add(animations);


        JButton reset =
                createButton(
                        "RESET CONTROLS",
                        450
                );

        add(reset);


        JButton back =
                createButton(
                        "BACK",
                        520
                );

        add(back);


        animations.addActionListener(
                e -> {

                    Settings.animations =
                            animations.isSelected();

                    Settings.save();
                }
        );


        reset.addActionListener(
                e -> {

                    Settings.leftKey =
                            KeyEvent.VK_LEFT;

                    Settings.rightKey =
                            KeyEvent.VK_RIGHT;

                    Settings.pauseKey =
                            KeyEvent.VK_P;

                    Settings.save();

                    updateLabels();
                }
        );


        back.addActionListener(
                e -> {

                    frame.setContentPane(
                            new MainMenu(frame)
                    );

                    frame.revalidate();
                    frame.repaint();
                }
        );


        updateLabels();
    }


    private JLabel createLabel(
            String text,
            int y) {

        JLabel label =
                new JLabel();

        label.setBounds(
                390,
                y,
                300,
                35
        );

        label.setForeground(
                Color.WHITE
        );

        label.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        16
                )
        );

        add(label);

        return label;
    }


    private JButton createButton(
            String text,
            int y) {

        JButton button =
                new JButton(text);

        button.setBounds(
                700,
                y,
                180,
                40
        );

        button.setForeground(
                Color.WHITE
        );

        button.setBackground(
                new Color(
                        15, 15, 40
                )
        );

        button.setFocusPainted(false);

        button.setBorder(
                BorderFactory.createLineBorder(
                        Color.CYAN
                )
        );

        return button;
    }


    private void changeKey(
            int type) {

        JDialog dialog =
                new JDialog(
                        frame,
                        "Press New Key",
                        true
                );

        dialog.setSize(
                400,
                180
        );

        dialog.setLocationRelativeTo(
                frame
        );

        JLabel label =
                new JLabel(
                        "Press the key you want to use",
                        SwingConstants.CENTER
                );

        dialog.add(label);


        dialog.addKeyListener(
                new KeyAdapter() {

                    @Override
                    public void keyPressed(
                            KeyEvent e) {

                        if (type == 1) {

                            Settings.leftKey =
                                    e.getKeyCode();
                        }

                        if (type == 2) {

                            Settings.rightKey =
                                    e.getKeyCode();
                        }

                        if (type == 3) {

                            Settings.pauseKey =
                                    e.getKeyCode();
                        }


                        Settings.save();

                        updateLabels();

                        dialog.dispose();
                    }
                }
        );


        dialog.setFocusable(true);

        dialog.setVisible(true);

        dialog.requestFocusInWindow();
    }


    private void updateLabels() {

        leftLabel.setText(
                "Move Left: "
                + KeyEvent.getKeyText(
                        Settings.leftKey
                )
        );


        rightLabel.setText(
                "Move Right: "
                + KeyEvent.getKeyText(
                        Settings.rightKey
                )
        );


        pauseLabel.setText(
                "Pause: "
                + KeyEvent.getKeyText(
                        Settings.pauseKey
                )
        );
    }
}
