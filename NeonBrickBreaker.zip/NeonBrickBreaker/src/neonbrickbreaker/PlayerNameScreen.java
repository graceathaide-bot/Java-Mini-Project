package neonbrickbreaker;

import javax.swing.*;
import java.awt.*;

public class PlayerNameScreen extends JPanel {

    private JFrame frame;

    private JTextField nameField;

    public PlayerNameScreen(
            JFrame frame) {

        this.frame = frame;

        setLayout(null);

        setBackground(
                new Color(
                        5, 5, 18
                )
        );

        JLabel title =
                new JLabel(
                        "PLAYER SETUP",
                        SwingConstants.CENTER
                );

        title.setBounds(
                340,
                100,
                600,
                60
        );

        title.setForeground(
                Color.CYAN
        );

        title.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        42
                )
        );

        add(title);


        JLabel instruction =
                new JLabel(
                        "ENTER YOUR NAME",
                        SwingConstants.CENTER
                );

        instruction.setBounds(
                390,
                190,
                500,
                35
        );

        instruction.setForeground(
                Color.WHITE
        );

        instruction.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        18
                )
        );

        add(instruction);


        nameField =
                new JTextField();

        nameField.setBounds(
                440,
                240,
                400,
                55
        );

        nameField.setHorizontalAlignment(
                JTextField.CENTER
        );

        nameField.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        22
                )
        );

        nameField.setBackground(
                new Color(
                        18, 18, 40
                )
        );

        nameField.setForeground(
                Color.WHITE
        );

        nameField.setCaretColor(
                Color.CYAN
        );

        add(nameField);


        JButton continueButton =
                new JButton(
                        "CONTINUE"
                );

        continueButton.setBounds(
                440,
                330,
                400,
                52
        );

        styleButton(
                continueButton
        );

        add(continueButton);


        JButton back =
                new JButton(
                        "BACK"
                );

        back.setBounds(
                440,
                400,
                400,
                45
        );

        styleButton(back);

        add(back);


        continueButton.addActionListener(
                e -> continueGame()
        );

        nameField.addActionListener(
                e -> continueGame()
        );


        back.addActionListener(e -> {

            frame.setContentPane(
                    new MainMenu(frame)
            );

            frame.revalidate();
            frame.repaint();
        });


        SwingUtilities.invokeLater(() ->
                nameField.requestFocusInWindow()
        );
    }


    private void continueGame() {

        String name =
                nameField.getText()
                .trim();

        if (name.isEmpty()) {

            name = "PLAYER";
        }

        if (name.length() > 12) {

            name =
                    name.substring(
                            0,
                            12
                    );
        }

        Main.currentPlayer =
                name;

        frame.setContentPane(
                new LevelSelect(frame)
        );

        frame.revalidate();
        frame.repaint();
    }


    private void styleButton(
            JButton button) {

        button.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        16
                )
        );

        button.setForeground(
                Color.WHITE
        );

        button.setBackground(
                new Color(
                        15, 15, 40
                )
        );

        button.setFocusPainted(false);

        button.setBorder(
                BorderFactory.createLineBorder(
                        Color.CYAN
                )
        );
    }
}