package neonbrickbreaker;

import javax.swing.*;
import java.awt.*;

public class LoadingScreen extends JPanel {

    private int progress = 0;

    private javax.swing.Timer timer;

    public LoadingScreen(JFrame frame) {

        setBackground(
                new Color(5, 5, 18)
        );

        timer = new javax.swing.Timer(
                25,
                e -> {

                    progress++;

                    repaint();

                    if (progress >= 100) {

                        timer.stop();

                        frame.setContentPane(
                                new MainMenu(frame)
                        );

                        frame.revalidate();
                        frame.repaint();
                    }
                }
        );

        timer.start();
    }

    @Override
    protected void paintComponent(
            Graphics g) {

        super.paintComponent(g);

        Graphics2D g2 =
                (Graphics2D) g;

        g2.setRenderingHint(
                RenderingHints.KEY_ANTIALIASING,
                RenderingHints.VALUE_ANTIALIAS_ON
        );

        // TITLE

        g2.setColor(Color.CYAN);

        g2.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        72
                )
        );

        String title =
                "NEON BREAK";

        int titleX =
                (getWidth()
                - g2.getFontMetrics()
                .stringWidth(title))
                / 2;

        g2.drawString(
                title,
                titleX,
                270
        );

        // SUBTITLE

        g2.setColor(
                new Color(
                        180,
                        80,
                        255
                )
        );

        g2.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        22
                )
        );

        String subtitle =
                "ARCADE TIME TRIAL";

        int subX =
                (getWidth()
                - g2.getFontMetrics()
                .stringWidth(subtitle))
                / 2;

        g2.drawString(
                subtitle,
                subX,
                315
        );

        // LOADING

        g2.setColor(Color.WHITE);

        g2.setFont(
                new Font(
                        "Arial",
                        Font.PLAIN,
                        16
                )
        );

        String loading =
                "INITIALIZING ARCADE SYSTEM...";

        int loadingX =
                (getWidth()
                - g2.getFontMetrics()
                .stringWidth(loading))
                / 2;

        g2.drawString(
                loading,
                loadingX,
                380
        );

        // BAR BACKGROUND

        int barWidth = 650;

        int barX =
                (getWidth() - barWidth) / 2;

        g2.setColor(
                new Color(
                        25, 25, 50
                )
        );

        g2.fillRoundRect(
                barX,
                420,
                barWidth,
                20,
                10,
                10
        );

        // BAR

        g2.setColor(Color.CYAN);

        g2.fillRoundRect(
                barX,
                420,
                progress * 6,
                20,
                10,
                10
        );

        // PERCENTAGE

        g2.setColor(Color.WHITE);

        g2.drawString(
                progress + "%",
                620,
                475
        );
    }
}