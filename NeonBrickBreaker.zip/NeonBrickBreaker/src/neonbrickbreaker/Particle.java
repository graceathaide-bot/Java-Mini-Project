package neonbrickbreaker;

import java.awt.*;
import java.util.Random;

public class Particle {

    double x;
    double y;

    double dx;
    double dy;

    int life = 30;

    Random random =
            new Random();


    public Particle(
            int x,
            int y) {

        this.x = x;
        this.y = y;

        dx =
                random.nextDouble() * 5 - 2.5;

        dy =
                random.nextDouble() * 5 - 2.5;
    }


    public void update() {

        x += dx;
        y += dy;

        life--;
    }


    public void draw(
            Graphics2D g) {

        int alpha =
                Math.max(
                        0,
                        life * 8
                );

        g.setColor(
                new Color(
                        0,
                        220,
                        255,
                        alpha
                )
        );

        g.fillOval(
                (int)x,
                (int)y,
                6,
                6
        );
    }
}