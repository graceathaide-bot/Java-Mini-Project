package neonbrickbreaker;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;

public class LevelCompleteScreen extends JPanel {

    private JFrame frame;

    public LevelCompleteScreen(
            JFrame frame,
            int level,
            String player,
            long time,
            boolean record) {

        this.frame = frame;

        setLayout(null);

        setBackground(new Color(5, 5, 18));

        // =========================
        // TITLE
        // =========================

        JLabel title = new JLabel(
                "★ LEVEL COMPLETE ★",
                SwingConstants.CENTER
        );

        title.setBounds(
                300, 35, 680, 60
        );

        title.setForeground(Color.CYAN);

        title.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        42
                )
        );

        add(title);


        // =========================
        // PLAYER + LEVEL
        // =========================

        JLabel playerLabel = new JLabel(
                player + "  •  LEVEL " + level,
                SwingConstants.CENTER
        );

        playerLabel.setBounds(
                300, 100, 680, 35
        );

        playerLabel.setForeground(Color.WHITE);

        playerLabel.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        18
                )
        );

        add(playerLabel);


        // =========================
        // TIME
        // =========================

        JLabel timeLabel = new JLabel(
                Leaderboard.formatTime(time),
                SwingConstants.CENTER
        );

        timeLabel.setBounds(
                300, 135, 680, 65
        );

        timeLabel.setForeground(
                new Color(0, 240, 255)
        );

        timeLabel.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        48
                )
        );

        add(timeLabel);


        // =========================
        // RECORD MESSAGE
        // =========================

        JLabel recordLabel = new JLabel(
                record
                ? "★ NEW TOP 5 RECORD ★"
                : "TIME RECORDED",
                SwingConstants.CENTER
        );

        recordLabel.setBounds(
                300, 195, 680, 35
        );

        recordLabel.setForeground(
                record
                ? new Color(255, 210, 50)
                : Color.LIGHT_GRAY
        );

        recordLabel.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        17
                )
        );

        add(recordLabel);


        // =========================
        // LEADERBOARD TITLE
        // =========================

        JLabel leaderboardTitle =
                new JLabel(
                        "LEVEL " + level + " LEADERBOARD",
                        SwingConstants.CENTER
                );

        leaderboardTitle.setBounds(
                360, 235, 560, 35
        );

        leaderboardTitle.setForeground(
                new Color(190, 80, 255)
        );

        leaderboardTitle.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        20
                )
        );

        add(leaderboardTitle);


        // =========================
        // LEADERBOARD
        // =========================

        JTextArea leaderboard =
                new JTextArea();

        leaderboard.setEditable(false);

        leaderboard.setBackground(
                new Color(10, 10, 30)
        );

        leaderboard.setForeground(
                Color.WHITE
        );

        leaderboard.setFont(
                new Font(
                        "Monospaced",
                        Font.BOLD,
                        16
                )
        );

        leaderboard.setBorder(
                BorderFactory.createLineBorder(
                        Color.CYAN,
                        1
                )
        );


        StringBuilder board =
                new StringBuilder();

        board.append(
                "       RANK       PLAYER       TIME\n"
        );

        board.append(
                "       ───────────────────────────\n"
        );


        ArrayList<Leaderboard.Record> scores =
                Leaderboard.getScores(level);


        if (scores.isEmpty()) {

            board.append(
                    "             NO RECORDS YET\n"
            );

        } else {

            for (int i = 0;
                 i < scores.size();
                 i++) {

                Leaderboard.Record r =
                        scores.get(i);


                String marker =
                        r.name.equals(player)
                        && r.time == time
                        ? " ★"
                        : "";


                board.append(
                        String.format(
                                "        %-4d    %-12s   %s%s\n",
                                i + 1,
                                r.name,
                                Leaderboard.formatTime(
                                        r.time
                                ),
                                marker
                        )
                );
            }
        }


        leaderboard.setText(
                board.toString()
        );


        JScrollPane scrollPane =
                new JScrollPane(
                        leaderboard
                );

        scrollPane.setBounds(
                330, 275, 620, 190
        );

        scrollPane.setBorder(
                BorderFactory.createLineBorder(
                        Color.CYAN,
                        1
                )
        );

        add(scrollPane);


        // =========================
        // NEXT LEVEL
        // =========================

        JButton nextButton =
                createButton(
                        level < 5
                        ? "NEXT LEVEL"
                        : "VIEW ALL LEADERBOARDS",
                        490
                );

        add(nextButton);


        // =========================
        // MAIN MENU
        // =========================

        JButton menuButton =
                createButton(
                        "MAIN MENU",
                        550
                );

        add(menuButton);


        // =========================
        // BUTTON ACTIONS
        // =========================

        nextButton.addActionListener(e -> {

            if (level < 5) {

                frame.setContentPane(
                        new GamePanel(
                                frame,
                                level + 1,
                                player
                        )
                );

            } else {

                frame.setContentPane(
                        new LeaderboardMenu(
                                frame
                        )
                );
            }

            frame.revalidate();
            frame.repaint();
        });


        menuButton.addActionListener(e -> {

            frame.setContentPane(
                    new MainMenu(frame)
            );

            frame.revalidate();
            frame.repaint();
        });
    }


    // =========================
    // BUTTON STYLE
    // =========================

    private JButton createButton(
            String text,
            int y) {

        JButton button =
                new JButton(text);

        button.setBounds(
                440,
                y,
                400,
                45
        );

        button.setForeground(
                Color.WHITE
        );

        button.setBackground(
                new Color(
                        15, 15, 40
                )
        );

        button.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        15
                )
        );

        button.setFocusPainted(false);

        button.setBorder(
                BorderFactory.createLineBorder(
                        Color.CYAN,
                        1
                )
        );

        return button;
    }


    // =========================
    // BACKGROUND
    // =========================

    @Override
    protected void paintComponent(
            Graphics g) {

        super.paintComponent(g);

        Graphics2D g2 =
                (Graphics2D) g;

        g2.setRenderingHint(
                RenderingHints.KEY_ANTIALIASING,
                RenderingHints.VALUE_ANTIALIAS_ON
        );


        // Grid

        g2.setColor(
                new Color(
                        12, 12, 32
                )
        );


        for (int x = 0;
             x < getWidth();
             x += 40) {

            g2.drawLine(
                    x,
                    0,
                    x,
                    getHeight()
            );
        }


        for (int y = 0;
             y < getHeight();
             y += 40) {

            g2.drawLine(
                    0,
                    y,
                    getWidth(),
                    y
            );
        }
    }
}