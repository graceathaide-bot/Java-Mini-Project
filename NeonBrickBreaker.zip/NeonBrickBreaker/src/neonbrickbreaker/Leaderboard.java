package neonbrickbreaker;

import java.io.*;
import java.util.*;

public class Leaderboard {

    public static class Record
            implements Serializable {

        public String name;
        public long time;


        public Record(
                String name,
                long time) {

            this.name = name;
            this.time = time;
        }
    }


    private static ArrayList<Record>[]
            records;


    private static final String FILE =
            System.getProperty("user.home")
            + File.separator
            + "neonbreak_leaderboard.dat";


    static {

        load();
    }


    private static void createEmpty() {

        records =
                new ArrayList[5];

        for (int i = 0;
             i < 5;
             i++) {

            records[i] =
                    new ArrayList<>();
        }
    }


    public static void addScore(
            int level,
            String name,
            long time) {

        if (records == null) {

            createEmpty();
        }


        records[level - 1].add(
                new Record(
                        name,
                        time
                )
        );


        records[level - 1].sort(
                Comparator.comparingLong(
                        r -> r.time
                )
        );


        if (records[level - 1].size()
                > 5) {

            records[level - 1].remove(5);
        }


        save();
    }


    public static ArrayList<Record>
            getScores(
                    int level) {

        if (records == null) {

            createEmpty();
        }

        return records[level - 1];
    }


    public static long getBestTime(
            int level) {

        ArrayList<Record> list =
                getScores(level);

        if (list.isEmpty()) {

            return -1;
        }

        return list.get(0).time;
    }


    public static boolean isTopFive(
            int level,
            long time) {

        ArrayList<Record> list =
                getScores(level);

        return list.size() < 5
                || time < list.get(
                        list.size() - 1
                ).time;
    }


    public static String formatTime(
            long millis) {

        long minutes =
                millis / 60000;

        long seconds =
                (millis / 1000) % 60;

        long hundredths =
                (millis % 1000) / 10;


        return String.format(
                "%02d:%02d.%02d",
                minutes,
                seconds,
                hundredths
        );
    }


    private static void save() {

        try {

            ObjectOutputStream out =
                    new ObjectOutputStream(
                            new FileOutputStream(
                                    FILE
                            )
                    );

            out.writeObject(
                    records
            );

            out.close();

        } catch (Exception e) {

            e.printStackTrace();
        }
    }


    private static void load() {

        File file =
                new File(FILE);


        if (!file.exists()) {

            createEmpty();

            return;
        }


        try {

            ObjectInputStream in =
                    new ObjectInputStream(
                            new FileInputStream(
                                    file
                            )
                    );

            records =
                    (ArrayList<Record>[])
                    in.readObject();

            in.close();

        } catch (Exception e) {

            createEmpty();
        }
    }
}