package neonbrickbreaker;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;

public class GamePanel
        extends JPanel
        implements ActionListener {

    private static final int WIDTH = 1280;
    private static final int HEIGHT = 720;

    private JFrame frame;

    private int level;

    private String playerName;


    // GAME OBJECTS

    private ArrayList<Ball> balls =
            new ArrayList<>();

    private ArrayList<Brick> bricks =
            new ArrayList<>();

    private ArrayList<Obstacle> obstacles =
            new ArrayList<>();

    private ArrayList<PowerUp> powerUps =
            new ArrayList<>();

    private ArrayList<Particle> particles =
            new ArrayList<>();


    private Random random =
            new Random();


    // PADDLE

    private int paddleX = 540;

    private int paddleWidth = 200;

    private final int paddleHeight = 18;

    private final int paddleY = 650;


    // STATES

    private boolean leftPressed;
    private boolean rightPressed;

    private boolean started = false;

    private boolean paused = false;

    private boolean gameOver = false;


    // PLAYER

    private int lives = 3;


    // TIME

    private long startTime;

    private long elapsedTime;

    private int timeLimit;


    // COUNTDOWN

    private int countdown = 3;

    private long countdownStart;


    private javax.swing.Timer timer;


    public GamePanel(
            JFrame frame,
            int level,
            String playerName) {

        this.frame = frame;

        this.level = level;

        this.playerName =
                playerName;


        Settings.load();


        timeLimit =
                getTimeLimit();


        setPreferredSize(
                new Dimension(
                        WIDTH,
                        HEIGHT
                )
        );


        setFocusable(true);


        setupControls();


        createLevel();


        countdownStart =
                System.currentTimeMillis();


        timer =
                new javax.swing.Timer(
                        10,
                        this
                );


        timer.start();


        SwingUtilities.invokeLater(
                () ->
                requestFocusInWindow()
        );
    }


    private int getTimeLimit() {

        switch (level) {

            case 1:
                return 180;

            case 2:
                return 160;

            case 3:
                return 140;

            case 4:
                return 120;

            default:
                return 100;
        }
    }


    // ==================================================
    // LEVEL CREATION
    // ==================================================

    private void createLevel() {

        bricks.clear();

        obstacles.clear();

        balls.clear();


        int brickWidth = 110;

        int brickHeight = 32;

        int startX = 65;

        int startY = 100;


        int rows =
                2 + level;


        for (int r = 0;
             r < rows;
             r++) {

            for (int c = 0;
                 c < 10;
                 c++) {

                boolean create =
                        true;


                // Create some gaps

                if (level >= 3
                        && r == 3
                        && (c == 4
                        || c == 5)) {

                    create = false;
                }


                if (level >= 4
                        && r == 4
                        && (c == 1
                        || c == 8)) {

                    create = false;
                }


                if (level == 5
                        && r == 5
                        && (c == 3
                        || c == 6)) {

                    create = false;
                }


                if (!create) {

                    continue;
                }


                int hits = 1;


                // LEVEL 2

                if (level >= 2
                        && r % 2 == 0) {

                    hits = 2;
                }


                // LEVEL 3+

                if (level >= 3
                        && r == 0) {

                    hits = 3;
                }


                // LEVEL 5

                if (level == 5
                        && r % 2 == 0) {

                    hits = 3;
                }


                bricks.add(
                        new Brick(
                                startX
                                + c
                                * brickWidth,

                                startY
                                + r
                                * brickHeight,

                                brickWidth,

                                brickHeight,

                                hits
                        )
                );
            }
        }


        createObstacles();


        double speed =
                5.0
                + level
                * 0.8;


        balls.add(
                new Ball(
                        WIDTH / 2.0,
                        520,
                        speed,
                        -speed
                )
        );
    }


    private void createObstacles() {

        if (level >= 3) {

            obstacles.add(
                    new Obstacle(
                            350,
                            300,
                            220,
                            20
                    )
            );

            obstacles.add(
                    new Obstacle(
                            710,
                            300,
                            220,
                            20
                    )
            );
        }


        if (level >= 4) {

            obstacles.add(
                    new Obstacle(
                            170,
                            390,
                            220,
                            20
                    )
            );

            obstacles.add(
                    new Obstacle(
                            890,
                            390,
                            220,
                            20
                    )
            );
        }


        if (level == 5) {

            obstacles.add(
                    new Obstacle(
                            500,
                            450,
                            280,
                            20
                    )
            );
        }
    }


    // ==================================================
    // CONTROLS
    // ==================================================

    private void setupControls() {

        addKeyListener(
                new KeyAdapter() {

                    @Override
                    public void keyPressed(
                            KeyEvent e) {

                        int key =
                                e.getKeyCode();


                        if (key ==
                                Settings.leftKey) {

                            leftPressed = true;
                        }


                        if (key ==
                                Settings.rightKey) {

                            rightPressed = true;
                        }


                        if (key ==
                                Settings.pauseKey) {

                            if (started
                                    && !gameOver) {

                                paused =
                                        !paused;
                            }
                        }


                        if (key ==
                                KeyEvent.VK_R) {

                            if (gameOver) {

                                restart();
                            }
                        }


                        if (key ==
                                KeyEvent.VK_ESCAPE) {

                            timer.stop();

                            frame.setContentPane(
                                    new MainMenu(
                                            frame
                                    )
                            );

                            frame.revalidate();

                            frame.repaint();
                        }
                    }


                    @Override
                    public void keyReleased(
                            KeyEvent e) {

                        int key =
                                e.getKeyCode();


                        if (key ==
                                Settings.leftKey) {

                            leftPressed = false;
                        }


                        if (key ==
                                Settings.rightKey) {

                            rightPressed = false;
                        }
                    }
                }
        );
    }


    // ==================================================
    // GAME LOOP
    // ==================================================

    @Override
    public void actionPerformed(
            ActionEvent e) {


        // COUNTDOWN

        if (!started
                && !gameOver) {

            long elapsed =
                    System.currentTimeMillis()
                    - countdownStart;


            countdown =
                    3
                    - (int)
                    (elapsed / 1000);


            if (countdown <= 0) {

                started = true;

                startTime =
                        System.currentTimeMillis();
            }


            repaint();

            return;
        }


        if (paused
                || gameOver) {

            repaint();

            return;
        }


        elapsedTime =
                System.currentTimeMillis()
                - startTime;


        // TIME LIMIT

        if (elapsedTime
                >= timeLimit
                * 1000L) {

            elapsedTime =
                    timeLimit
                    * 1000L;

            gameOver = true;

            repaint();

            return;
        }


        movePaddle();

        updateBalls();

        updatePowerUps();

        updateParticles();

        checkWin();


        repaint();
    }


    // ==================================================
    // PADDLE
    // ==================================================

    private void movePaddle() {

        int speed = 12;


        if (leftPressed) {

            paddleX -= speed;
        }


        if (rightPressed) {

            paddleX += speed;
        }


        if (paddleX < 0) {

            paddleX = 0;
        }


        if (paddleX
                + paddleWidth
                > WIDTH) {

            paddleX =
                    WIDTH
                    - paddleWidth;
        }
    }


    // ==================================================
    // BALL
    // ==================================================

    private void updateBalls() {

        for (int i =
                balls.size() - 1;
                i >= 0;
                i--) {

            Ball ball =
                    balls.get(i);


            ball.update(
                    Settings.animations
            );


            // WALLS

            if (ball.x <= 0) {

                ball.x = 0;

                ball.dx =
                        Math.abs(
                                ball.dx
                        );
            }


            if (ball.x
                    + ball.size
                    >= WIDTH) {

                ball.x =
                        WIDTH
                        - ball.size;

                ball.dx =
                        -Math.abs(
                                ball.dx
                        );
            }


            if (ball.y <= 70) {

                ball.y = 70;

                ball.dy =
                        Math.abs(
                                ball.dy
                        );
            }


            Rectangle ballRect =
                    new Rectangle(
                            (int)ball.x,
                            (int)ball.y,
                            ball.size,
                            ball.size
                    );


            // PADDLE

            Rectangle paddleRect =
                    new Rectangle(
                            paddleX,
                            paddleY,
                            paddleWidth,
                            paddleHeight
                    );


            if (ballRect.intersects(
                    paddleRect)
                    && ball.dy > 0) {

                ball.dy =
                        -Math.abs(
                                ball.dy
                        );


                double center =
                        paddleX
                        + paddleWidth
                        / 2.0;


                double hit =
                        ball.x
                        + ball.size / 2.0
                        - center;


                ball.dx =
                        hit / 15.0;


                if (Math.abs(
                        ball.dx) < 1) {

                    ball.dx =
                            ball.dx < 0
                            ? -1
                            : 1;
                }


                ball.y =
                        paddleY
                        - ball.size;
            }


            // OBSTACLES

            for (Obstacle obstacle :
                    obstacles) {

                if (ballRect.intersects(
                        obstacle.getBounds())) {

                    ball.dy =
                            -ball.dy;

                    break;
                }
            }


            // BRICKS

            for (Brick brick :
                    bricks) {

                if (brick.destroyed) {

                    continue;
                }


                if (ballRect.intersects(
                        brick.getBounds())) {

                    brick.hit();


                    ball.dy =
                            -ball.dy;


                    createParticles(
                            brick.x
                            + brick.width / 2,
                            brick.y
                            + brick.height / 2
                    );


                    if (brick.destroyed) {

                        if (random.nextInt(
                                100) < 20) {

                            spawnPowerUp(
                                    brick.x,
                                    brick.y
                            );
                        }
                    }


                    break;
                }
            }


            // BALL LOST

            if (ball.y > HEIGHT) {

                balls.remove(i);
            }
        }


        if (balls.isEmpty()) {

            lives--;


            if (lives <= 0) {

                gameOver = true;

            } else {

                resetBall();
            }
        }
    }


    // ==================================================
    // POWER UPS
    // ==================================================

    private void spawnPowerUp(
            int x,
            int y) {

        String[] types = {

            "PADDLE",
            "SLOW",
            "LIFE",
            "MULTI"
        };


        String type =
                types[
                        random.nextInt(
                                types.length
                        )
                ];


        powerUps.add(
                new PowerUp(
                        x,
                        y,
                        type
                )
        );
    }


    private void updatePowerUps() {

        for (int i =
                powerUps.size() - 1;
                i >= 0;
                i--) {

            PowerUp power =
                    powerUps.get(i);


            power.update();


            Rectangle powerRect =
                    new Rectangle(
                            (int)power.x,
                            (int)power.y,
                            power.size,
                            power.size
                    );


            Rectangle paddleRect =
                    new Rectangle(
                            paddleX,
                            paddleY,
                            paddleWidth,
                            paddleHeight
                    );


            if (powerRect.intersects(
                    paddleRect)) {

                activatePowerUp(
                        power.type
                );

                powerUps.remove(i);

                continue;
            }


            if (power.y > HEIGHT) {

                powerUps.remove(i);
            }
        }
    }


    private void activatePowerUp(
            String type) {

        if (type.equals(
                "PADDLE")) {

            paddleWidth = 280;
        }


        else if (type.equals(
                "SLOW")) {

            for (Ball ball :
                    balls) {

                ball.dx *= 0.65;

                ball.dy *= 0.65;
            }
        }


        else if (type.equals(
                "LIFE")) {

            lives++;
        }


        else if (type.equals(
                "MULTI")) {

            if (!balls.isEmpty()) {

                Ball b =
                        balls.get(0);


                balls.add(
                        new Ball(
                                b.x,
                                b.y,
                                -b.dx,
                                b.dy
                        )
                );


                balls.add(
                        new Ball(
                                b.x,
                                b.y,
                                b.dx,
                                -b.dy
                        )
                );
            }
        }
    }


    // ==================================================
    // WIN
    // ==================================================

    private void checkWin() {

        for (Brick brick :
                bricks) {

            if (!brick.destroyed) {

                return;
            }
        }


        elapsedTime =
                System.currentTimeMillis()
                - startTime;


        timer.stop();


        boolean record =
                Leaderboard.isTopFive(
                        level,
                        elapsedTime
                );


        Leaderboard.addScore(
                level,
                playerName,
                elapsedTime
        );


        frame.setContentPane(
                new LevelCompleteScreen(
                        frame,
                        level,
                        playerName,
                        elapsedTime,
                        record
                )
        );


        frame.revalidate();

        frame.repaint();
    }


    // ==================================================
    // RESET BALL
    // ==================================================

    private void resetBall() {

        balls.clear();


        double speed =
                5.0
                + level * 0.8;


        balls.add(
                new Ball(
                        WIDTH / 2.0,
                        520,
                        speed,
                        -speed
                )
        );


        requestFocusInWindow();
    }


    // ==================================================
    // RESTART
    // ==================================================

    private void restart() {

        paddleX = 540;

        paddleWidth = 200;

        lives = 3;

        started = false;

        paused = false;

        gameOver = false;

        elapsedTime = 0;

        powerUps.clear();

        particles.clear();

        countdown = 3;

        countdownStart =
                System.currentTimeMillis();

        createLevel();

        timer.start();

        requestFocusInWindow();
    }


    // ==================================================
    // PARTICLES
    // ==================================================

    private void createParticles(
            int x,
            int y) {

        if (!Settings.animations) {

            return;
        }


        for (int i = 0;
             i < 15;
             i++) {

            particles.add(
                    new Particle(
                            x,
                            y
                    )
            );
        }
    }


    private void updateParticles() {

        for (int i =
                particles.size() - 1;
                i >= 0;
                i--) {

            Particle particle =
                    particles.get(i);


            particle.update();


            if (particle.life <= 0) {

                particles.remove(i);
            }
        }
    }


    // ==================================================
    // DRAW
    // ==================================================

    @Override
    protected void paintComponent(
            Graphics g) {

        super.paintComponent(g);


        Graphics2D g2 =
                (Graphics2D)
                g.create();


        g2.setRenderingHint(
                RenderingHints.KEY_ANTIALIASING,
                RenderingHints.VALUE_ANTIALIAS_ON
        );


        // BACKGROUND

        g2.setColor(
                new Color(
                        5, 5, 18
                )
        );

        g2.fillRect(
                0,
                0,
                WIDTH,
                HEIGHT
        );


        drawGrid(g2);


        // HUD

        g2.setColor(
                new Color(
                        10, 10, 32
                )
        );

        g2.fillRect(
                0,
                0,
                WIDTH,
                70
        );


        g2.setColor(
                Color.CYAN
        );

        g2.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        17
                )
        );


        g2.drawString(
                "PLAYER: "
                + playerName,
                25,
                42
        );


        g2.drawString(
                "LEVEL: "
                + level,
                240,
                42
        );


        g2.drawString(
                "TIME: "
                + Leaderboard.formatTime(
                        elapsedTime
                ),
                390,
                42
        );


        g2.drawString(
                "LIMIT: "
                + String.format(
                        "%02d:00",
                        timeLimit
                ),
                630,
                42
        );


        g2.drawString(
                "LIVES: "
                + lives,
                850,
                42
        );


        long best =
                Leaderboard.getBestTime(
                        level
                );


        String bestText =
                best == -1
                ? "--:--.--"
                : Leaderboard
                        .formatTime(
                                best
                        );


        g2.drawString(
                "BEST: "
                + bestText,
                1020,
                42
        );


        // BRICKS

        for (Brick brick :
                bricks) {

            if (!brick.destroyed) {

                brick.draw(g2);
            }
        }


        // OBSTACLES

        for (Obstacle obstacle :
                obstacles) {

            obstacle.draw(g2);
        }


        // POWER UPS

        for (PowerUp power :
                powerUps) {

            power.draw(g2);
        }


        // BALLS

        for (Ball ball :
                balls) {

            ball.draw(
                    g2,
                    Settings.animations
            );
        }


        // PADDLE

        g2.setColor(
                Color.CYAN
        );

        g2.fillRoundRect(
                paddleX,
                paddleY,
                paddleWidth,
                paddleHeight,
                15,
                15
        );


        g2.setColor(
                Color.WHITE
        );

        g2.drawRoundRect(
                paddleX,
                paddleY,
                paddleWidth,
                paddleHeight,
                15,
                15
        );


        // PARTICLES

        for (Particle particle :
                particles) {

            particle.draw(g2);
        }


        // COUNTDOWN

        if (!started
                && !gameOver) {

            drawOverlay(
                    g2,
                    "" + Math.max(
                            countdown,
                            1
                    )
            );
        }


        // PAUSE

        if (paused) {

            drawOverlay(
                    g2,
                    "PAUSED"
            );
        }


        // GAME OVER

        if (gameOver) {

            drawOverlay(
                    g2,
                    "GAME OVER"
            );


            g2.setColor(
                    Color.WHITE
            );

            g2.setFont(
                    new Font(
                            "Arial",
                            Font.BOLD,
                            18
                    )
            );


            String text =
                    "Press R to Retry"
                    + "     |     "
                    + "ESC for Menu";


            int x =
                    (WIDTH
                    - g2.getFontMetrics()
                    .stringWidth(text))
                    / 2;


            g2.drawString(
                    text,
                    x,
                    400
            );
        }


        g2.dispose();
    }


    private void drawGrid(
            Graphics2D g2) {

        g2.setColor(
                new Color(
                        12, 12, 32
                )
        );


        for (int x = 0;
             x < WIDTH;
             x += 40) {

            g2.drawLine(
                    x,
                    70,
                    x,
                    HEIGHT
            );
        }


        for (int y = 70;
             y < HEIGHT;
             y += 40) {

            g2.drawLine(
                    0,
                    y,
                    WIDTH,
                    y
            );
        }
    }


    private void drawOverlay(
            Graphics2D g2,
            String text) {

        g2.setColor(
                new Color(
                        0,
                        0,
                        0,
                        180
                )
        );


        g2.fillRect(
                0,
                70,
                WIDTH,
                HEIGHT - 70
        );


        g2.setColor(
                Color.CYAN
        );


        g2.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        70
                )
        );


        int x =
                (WIDTH
                - g2.getFontMetrics()
                .stringWidth(text))
                / 2;


        g2.drawString(
                text,
                x,
                370
        );
    }
}