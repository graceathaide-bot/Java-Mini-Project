package neonbrickbreaker;

import javax.swing.*;
import java.awt.*;

public class MainMenu extends JPanel {

    private JFrame frame;

    public MainMenu(JFrame frame) {

        this.frame = frame;

        setLayout(null);

        setBackground(
                new Color(
                        5, 5, 18
                )
        );

        createButtons();
    }

    private void createButtons() {

        JButton play =
                createButton(
                        "PLAY TIME TRIAL",
                        280
                );

        JButton levels =
                createButton(
                        "SELECT LEVEL",
                        345
                );

        JButton leaderboard =
                createButton(
                        "LEADERBOARD",
                        410
                );

        JButton settings =
                createButton(
                        "SETTINGS",
                        475
                );

        JButton exit =
                createButton(
                        "EXIT",
                        540
                );


        play.addActionListener(e -> {

            frame.setContentPane(
                    new PlayerNameScreen(
                            frame
                    )
            );

            frame.revalidate();
            frame.repaint();
        });


        levels.addActionListener(e -> {

            frame.setContentPane(
                    new PlayerNameScreen(
                            frame
                    )
            );

            frame.revalidate();
            frame.repaint();
        });


        leaderboard.addActionListener(e -> {

            frame.setContentPane(
                    new LeaderboardMenu(
                            frame
                    )
            );

            frame.revalidate();
            frame.repaint();
        });


        settings.addActionListener(e -> {

            frame.setContentPane(
                    new SettingsMenu(
                            frame
                    )
            );

            frame.revalidate();
            frame.repaint();
        });


        exit.addActionListener(e ->
                System.exit(0)
        );
    }


    private JButton createButton(
            String text,
            int y) {

        JButton button =
                new JButton(text);

        button.setBounds(
                440,
                y,
                400,
                52
        );

        button.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        17
                )
        );

        button.setForeground(
                Color.WHITE
        );

        button.setBackground(
                new Color(
                        15, 15, 40
                )
        );

        button.setFocusPainted(false);

        button.setBorder(
                BorderFactory.createLineBorder(
                        Color.CYAN,
                        1
                )
        );

        button.addMouseListener(
                new java.awt.event.MouseAdapter() {

                    @Override
                    public void mouseEntered(
                            java.awt.event.MouseEvent e) {

                        button.setBackground(
                                new Color(
                                        25, 65, 90
                                )
                        );
                    }

                    @Override
                    public void mouseExited(
                            java.awt.event.MouseEvent e) {

                        button.setBackground(
                                new Color(
                                        15, 15, 40
                                )
                        );
                    }
                }
        );

        add(button);

        return button;
    }


    @Override
    protected void paintComponent(
            Graphics g) {

        super.paintComponent(g);

        Graphics2D g2 =
                (Graphics2D) g;

        g2.setRenderingHint(
                RenderingHints.KEY_ANTIALIASING,
                RenderingHints.VALUE_ANTIALIAS_ON
        );

        drawBackground(g2);

        // TITLE

        g2.setColor(Color.CYAN);

        g2.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        80
                )
        );

        String title =
                "NEON BREAK";

        int titleX =
                (1280
                - g2.getFontMetrics()
                .stringWidth(title))
                / 2;

        g2.drawString(
                title,
                titleX,
                150
        );

        // SUBTITLE

        g2.setColor(
                new Color(
                        180,
                        80,
                        255
                )
        );

        g2.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        22
                )
        );

        String subtitle =
                "ARCADE TIME TRIAL";

        int subX =
                (1280
                - g2.getFontMetrics()
                .stringWidth(subtitle))
                / 2;

        g2.drawString(
                subtitle,
                subX,
                190
        );

        // FOOTER

        g2.setColor(
                new Color(
                        120,
                        120,
                        150
                )
        );

        g2.setFont(
                new Font(
                        "Arial",
                        Font.PLAIN,
                        14
                )
        );

        g2.drawString(
                "FASTEST TIME WINS",
                560,
                680
        );
    }


    private void drawBackground(
            Graphics2D g2) {

        g2.setColor(
                new Color(
                        10, 10, 30
                )
        );

        for (int x = 0;
             x < 1280;
             x += 40) {

            g2.drawLine(
                    x,
                    0,
                    x,
                    720
            );
        }

        for (int y = 0;
             y < 720;
             y += 40) {

            g2.drawLine(
                    0,
                    y,
                    1280,
                    y
            );
        }
    }
}