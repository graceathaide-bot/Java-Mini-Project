package neonbrickbreaker;

import javax.swing.*;
import java.awt.*;

public class LevelSelect extends JPanel {

    private JFrame frame;

    private String[] names = {

        "LEVEL 1  •  EASY",
        "LEVEL 2  •  NORMAL",
        "LEVEL 3  •  HARD",
        "LEVEL 4  •  EXTREME",
        "LEVEL 5  •  NIGHTMARE"
    };

    private String[] descriptions = {

        "Classic bricks",
        "Multi-hit bricks",
        "Obstacles + strong bricks",
        "Fast ball + obstacles",
        "Maximum difficulty"
    };


    public LevelSelect(
            JFrame frame) {

        this.frame = frame;

        setLayout(null);

        setBackground(
                new Color(
                        5, 5, 18
                )
        );


        JLabel title =
                new JLabel(
                        "SELECT LEVEL",
                        SwingConstants.CENTER
                );

        title.setBounds(
                340,
                45,
                600,
                55
        );

        title.setForeground(
                Color.CYAN
        );

        title.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        40
                )
        );

        add(title);


        for (int i = 0;
             i < 5;
             i++) {

            int level =
                    i + 1;

            JButton button =
                    new JButton(
                            "<html><center>"
                            + names[i]
                            + "<br><font size='3'>"
                            + descriptions[i]
                            + "</font></center></html>"
                    );


            int x;
            int y;

            if (i < 4) {

                x =
                        (i % 2 == 0)
                        ? 270
                        : 680;

                y =
                        150
                        + (i / 2) * 125;

            } else {

                x = 475;
                y = 400;
            }


            button.setBounds(
                    x,
                    y,
                    330,
                    90
            );

            styleButton(
                    button
            );

            add(button);


            button.addActionListener(
                    e -> {

                        frame.setContentPane(
                                new GamePanel(
                                        frame,
                                        level,
                                        Main.currentPlayer
                                )
                        );

                        frame.revalidate();
                        frame.repaint();
                    }
            );
        }


        JButton back =
                new JButton(
                        "BACK"
                );

        back.setBounds(
                490,
                530,
                300,
                45
        );

        styleButton(back);

        add(back);


        back.addActionListener(e -> {

            frame.setContentPane(
                    new MainMenu(frame)
            );

            frame.revalidate();
            frame.repaint();
        });
    }


    private void styleButton(
            JButton button) {

        button.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        15
                )
        );

        button.setForeground(
                Color.WHITE
        );

        button.setBackground(
                new Color(
                        15, 15, 40
                )
        );

        button.setFocusPainted(false);

        button.setBorder(
                BorderFactory.createLineBorder(
                        Color.CYAN
                )
        );
    }
}