package neonbrickbreaker;

import java.awt.event.KeyEvent;
import java.io.*;
import java.util.Properties;

public class Settings {

    public static int leftKey =
            KeyEvent.VK_LEFT;

    public static int rightKey =
            KeyEvent.VK_RIGHT;

    public static int pauseKey =
            KeyEvent.VK_P;

    public static boolean animations =
            true;


    private static final String FILE =
            System.getProperty("user.home")
            + File.separator
            + "neonbreak_settings.properties";


    public static void save() {

        try {

            Properties p =
                    new Properties();

            p.setProperty(
                    "left",
                    "" + leftKey
            );

            p.setProperty(
                    "right",
                    "" + rightKey
            );

            p.setProperty(
                    "pause",
                    "" + pauseKey
            );

            p.setProperty(
                    "animations",
                    "" + animations
            );


            FileOutputStream out =
                    new FileOutputStream(
                            FILE
                    );

            p.store(
                    out,
                    "NEON BREAK SETTINGS"
            );

            out.close();

        } catch (Exception e) {

            e.printStackTrace();
        }
    }


    public static void load() {

        File file =
                new File(FILE);


        if (!file.exists()) {

            return;
        }


        try {

            Properties p =
                    new Properties();

            FileInputStream in =
                    new FileInputStream(
                            file
                    );

            p.load(in);

            in.close();


            leftKey =
                    Integer.parseInt(
                            p.getProperty(
                                    "left",
                                    "" + KeyEvent.VK_LEFT
                            )
                    );


            rightKey =
                    Integer.parseInt(
                            p.getProperty(
                                    "right",
                                    "" + KeyEvent.VK_RIGHT
                            )
                    );


            pauseKey =
                    Integer.parseInt(
                            p.getProperty(
                                    "pause",
                                    "" + KeyEvent.VK_P
                            )
                    );


            animations =
                    Boolean.parseBoolean(
                            p.getProperty(
                                    "animations",
                                    "true"
                            )
                    );

        } catch (Exception e) {

            e.printStackTrace();
        }
    }
}